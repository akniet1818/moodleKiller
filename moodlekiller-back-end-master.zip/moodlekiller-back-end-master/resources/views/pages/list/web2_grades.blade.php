@extends('layouts.course_grade')

@section('buttons_status_user_report')
    active
@endsection

@section('grades_table')
    тут будет таблица с оценками
@endsection
