<!--SNACKBAR-->
<fieldset id="snackbar">
    <legend id="wText" class="float-none w-auto text-center">
        Message
    </legend>
    This function isn't available yet.
</fieldset>

<footer class="container-fluid text-center p-3 disabled text-muted " style="background-color: #373a3c">
    <div class="text-center">
        <a href="https://astanait.edu.kz/en/aitu-2/" target="_blank" class="footerlink">
            <i class="fa fa-external-link-square fa-2x mx-2"></i>
        </a>
        <a href="https://www.instagram.com/astana_it_university/" target="_blank"  class="footerlink"><i class="fa fa-instagram  fa-2x mx-2"></i></a>
        <a href="https://www.youtube.com/channel/UCRUN152kvKPdLiYvcpOyFkQ" target="_blank"  class="footerlink"><i class="fa fa-youtube-square  fa-2x mx-2"></i></a>
        <a href="https://t.me/ait2u" target="_blank"  class="footerlink"><i class="fa fa-telegram  fa-2x mx-2"></i></a>
        <a href="https://www.facebook.com/astanaituniversity" target="_blank" class="footerlink"><i class="fa fa-facebook-square  fa-2x mx-2"></i></a>

    </div>

</footer>

<!--UNDER FOOTER-->
<div class="container-fluid text-center p-3 disabled text-muted " id="phrase"
     style="word-break: break-all; background-color: #2B2D2F	">
 <a href='https://t.me/lagmazavr' class='link-secondary' target='_blank'> <i class='fa fa-telegram '></i>
        Zavr </a>

    <wbr/>
+
    <a href='https://t.me/bioneis' class='link-secondary' target='_blank'><i class='fa fa-telegram '></i> Bione
      </a>
    <wbr/> + <a href='https://t.me/Qolymnan_usta' class='link-secondary' target='_blank'><i class='fa fa-telegram '></i> Akhi Brat </a>

</div>
<!--SNACKBAR-->
<fieldset id="snackbar">
    <legend id="wText" class="float-none w-auto text-center">
        Message
    </legend>
    This function isn't available yet.
</fieldset>
