<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;

class TasksController extends Controller
{
    public function index()
    {

        $data = [
            'tasks' => App\Models\Task::all(),

            'main_block' => [
                'a' => 'b',
                'c' => 'd',
            ],
        ];
        return view('tasks.index')->with($data);
    }
    public function show($id)
    {
        $task = App\Models\Task::find($id);
        return view('tasks.show', compact('task'));
    }
}
